<?php
include "config.php";

$mens_featured = $conn->query("SELECT * FROM categories where gender = 'Men' LIMIT 0,3;");
$women_featured = $conn->query("SELECT * FROM categories where gender = 'Women' LIMIT 0,3;");



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <section class="hero">
            <h1>New Collection</h1>
            <p>Discover our new arrivals for summer</p>
            <a href="#featureProducts" class="btn"><i class="fas fa-shopping-bag"></i> Shop Now</a>
        </section>

        <section class="smartfit">
            <h2>The perfect size, every time</h2>
            <p>Try SmartFit AI, our size recommendation tool today</p>
            <a href="model/" class="btn">Find your size</a>
        </section>

        <section class="quick-picks men" id="featureProducts">
            <h2>Men's Featured</h2>
            <div class="products">
                <?php 
                while ($row = $mens_featured->fetch_assoc()) {
                    ?>
                        <div class="product">
                            <a href="category.php?id=<?php echo $row['id']; ?>">
                                <img src="images/<?php echo $row['img']; ?>" alt="Men T-Shirt">
                                <p><?php echo $row['name']; ?></p>
                            </a>
                        </div>
                    <?php
                }
                ?>
                
             
            </div>
        </section>

        <section class="quick-picks women">
            <h2>Women's Featured</h2>
            <div class="products">
                <?php 
                while ($row = $women_featured->fetch_assoc()) {
                    ?>
                        <div class="product">
                            <a href="category.php?id=<?php echo $row['id']; ?>">
                                <img src="images/<?php echo $row['img']; ?>" alt="Men T-Shirt">
                                <p><?php echo $row['name']; ?></p>
                            </a>
                        </div>
                    <?php
                }
                ?>
               
            </div>
        </section>

        <section class="reviews">
            <h2>Reviews</h2>
            <div class="reviews-container">
                <div class="review">
                    <img src="images/review1.png" alt="Review 1">
                    <p>Looks good! Just as pictured.</p>
                    <p><strong>JOHN MORIS</strong></p>
                </div>
                <div class="review">
                    <img src="images/review2.png" alt="Review 2">
                    <p>Delivery time was fantastic.</p>
                    <p><strong>Anita Thornhill</strong></p>
                </div>
                <div class="review">
                    <img src="images/review3.png" alt="Review 3">
                    <p>Love the product.</p>
                    <p><strong>Sam Thomas</strong></p>
                </div>
            </div>
        </section>
    </main>

    
    <?php include "includes/footer.php"; ?>
    <script src="js/script.js"></script>
</body>

</html>
