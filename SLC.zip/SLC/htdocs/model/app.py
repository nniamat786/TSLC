from flask import Flask, request, jsonify
import tensorflow as tf
import cv2

app = Flask(__name__)

@app.route('/process_image', methods=['POST'])
def process_image():
    # Receive image file
    image_file = request.files['fileInput']
    # Process image 
    processed_result = process_with_model(image_file)
    # Return recommendation
    return jsonify({'size_recommendation': processed_result})

def process_with_model(image_file):
  
    image = cv2.imread(image_file)

    # processed_result 
    processed_result = "XL" 
    return processed_result

if __name__ == '__main__':
    app.run(debug=True)





