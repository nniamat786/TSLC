document.addEventListener("DOMContentLoaded", function () {
    const fileInput = document.getElementById("fileInput");
    const uploadButton = document.getElementById("uploadButton");

    const uploadBox =  document.getElementById("uploadBox");
    const processingBox =  document.getElementById("processingBox");
    const resultBox =  document.getElementById("resultBox");

    uploadButton.addEventListener("click", function () {
        console.log("Starting upload...");
        if (fileInput.files.length === 0) {
            alert("Please choose a file before uploading.");
            return;
        }

        uploadBox.style.display = 'none';
        processingBox.style.display = 'block';


        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append("file", file);

        fetch('upload.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json()) // assuming the PHP script returns JSON
            .then(data => {
                // Handle the response data here
                processingBox.style.display = 'none';
                console.log(data);

                resultBox.style.display = 'block';
                var recommendedSize = "<h1> Recommended Size for you is " + data.dressSize + "</h1>"; 
                var img = "<img src='/output/"+ data.output +"'>";
                resultBox.innerHTML = recommendedSize + img;

                

                


            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred while uploading the file.");
            });


    });
});
