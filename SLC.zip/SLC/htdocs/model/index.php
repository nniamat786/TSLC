<?php



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club - Upload Photos</title>
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            background-color: #000;
            color: #fff;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php include "../includes/header.php"; ?>

    <div class="container" style="display:block; margin-bottom: 100px">
        <section class="content">
            <h2>SmartFit AI - Upload Photos</h2>

            <div id="uploadBox">
                <div class="instructions">
                    <img src="model.png" alt="Model Image">
                    <div class="instructions-text">
                        <h3>How to Take Your Photos for Accurate Size Recommendations</h3>
                        <ol>
                            <li>Wear tight-fitting clothes.</li>
                            <li>Stand in a well-lit area with a plain background.</li>
                            <li>Stand straight with arms apart depicted in the image.</li>
                            <li>Take front view image, facing the camera.</li>
                            <li>Use a timer or get help to take the photos.</li>
                            <li>Upload clear photos to the form</li>
                        </ol>
                    </div>
                </div>
                <div class="upload-buttons">
                    <div class="upload-form">
                        <h3>Upload Picture</h3>
                        <input type="file" name="fileInput" id="fileInput" accept="image/*">
                        <button type="submit" id="uploadButton">Upload</button>
                    </div>
                </div>
            </div>


            <div id="processingBox" style="display: none;">
                <img src="/images/working.gif" width="300px">
                <h2>Processing, Please wait...</h2>
                <p>This could take upto a minute depending on image size</p>
            </div>

            <div id="resultBox" style="display: none;">

            </div>

        </section>
    </div>

    <?php include "../includes/footer.php"; ?>

    <script src="scripts.js"></script>
</body>

</html>