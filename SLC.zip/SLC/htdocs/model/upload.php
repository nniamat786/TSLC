<?php

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Define ranges for sizes
function getDressSize($height, $leg, $hip, $shoulder) {
    if ($height < 150 && $hip < 90) {
        return "Small (S)";
    } elseif ($height >= 150 && $height < 170 && $hip >= 90 && $hip < 100) {
        return "Medium (M)";
    } elseif ($height >= 170 && $height < 180 && $hip >= 100 && $hip < 110) {
        return "Large (L)";
    } elseif ($height >= 180 && $hip >= 110) {
        return "Extra Large (XL)";
    } else {
        return "Large (L)";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $uploadDir = '../input/';
        $fileName = generateRandomString() . basename($_FILES['file']['name']);
        $uploadFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {


            $measurements =  exec('python C:\xampp\cgi-bin\main.py C:\xampp\htdocs\input\\'. $fileName .' C:\xampp\htdocs\output\\'. $fileName);

            $measurementsArr = explode(" ", $measurements);

            $height = (int)($measurementsArr[0]);
            $leg = (int)($measurementsArr[1]);
            $hip = (int)($measurementsArr[2]);
            $shoulder = (int)($measurementsArr[3]);


            // File is successfully uploaded
            $response = [
                'status' => 'success',
                'message' => 'File uploaded successfully',
                'filePath' => $fileName,
                'dressSize' => getDressSize($height, $leg, $hip, $shoulder),
                'output' => $fileName
            ];
        } else {
            $response = [
                'status' => 'error',
                'message' => 'Failed to upload file'
            ];
        }
    } else {
        $response = [
            'status' => 'error',
            'message' => 'No file was uploaded'
        ];
    }

    // Set the response header to application/json
    header('Content-Type: application/json');
    echo json_encode($response);
}
