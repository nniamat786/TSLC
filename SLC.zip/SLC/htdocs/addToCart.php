<?php
include "config.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];

    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        // Registered user
        $user_id = $_SESSION['user_id'];

        // Check if the product is already in the cart
        $cartItem = $conn->query("SELECT * FROM cart WHERE user_id = $user_id AND product_id = $id")->fetch_assoc();
        
        if ($cartItem) {
            // Product already in the cart, update quantity
            $newQuantity = $cartItem['quantity'] + $quantity;
            $conn->query("UPDATE cart SET quantity = $newQuantity WHERE user_id = $user_id AND product_id = $id");
        } else {
            // Product not in the cart, add it
            $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $id, $quantity)");
        }

        echo "Product added to cart";
    } else {
        // Guest user
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }

        // Check if the product is already in the cart
        if (array_key_exists($id, $_SESSION['cart'])) {
            // Product already in the cart, update quantity
            $_SESSION['cart'][$id] += $quantity;
        } else {
            // Product not in the cart, add it
            $_SESSION['cart'][$id] = $quantity;
        }

        echo "Product added to cart";
    }
} else {
    // Invalid request method
    http_response_code(400);
    echo "Invalid request method";
}
?>
