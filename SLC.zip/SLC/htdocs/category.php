<?php 
include "config.php";

$id = $_GET['id'];

$category = $conn->query("SELECT * FROM categories where id = $id")->fetch_assoc();

$products = $conn->query("SELECT * FROM products where category = $id");


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <section class="category-section">

            <section class="quick-picks men">
                <h2><?php echo $category['name']; ?></h2>
                <div class="products">
                    
                    <?php 
                    while ($row = $products->fetch_assoc()) {
                        ?>
                            <div class="product">
                                <a href="product.php?id=<?php echo $row['id']; ?>">
                                    <img src="images/<?php echo $row['img']; ?>" alt="Men T-Shirt">
                                    <p><?php echo $row['name']; ?></p>
                                </a>
                            </div>
                        <?php
                    }
                    ?>

                   
                </div>
            </section>

           


           

          
        </section>
    </main>

    <?php include "includes/footer.php"; ?>

    <script src="js/script.js"></script>
</body>

</html>


