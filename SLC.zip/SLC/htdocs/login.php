<?php
include 'config.php';


if(isset($_POST['login-now'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the email exists in the database
    $user = $conn->query("SELECT * FROM users WHERE email = '$email'")->fetch_assoc();

    if ($user) {
        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['fName'] = $user['fName'];
            $_SESSION['lName'] = $user['lName'];
            $user_id = $user['id'];


            if (isset($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $product_id => $quantity) {
                    $product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
                    if ($product) {
                        $cartItem = $conn->query("SELECT * FROM cart WHERE user_id = $user_id AND product_id = $product_id")->fetch_assoc();
                        if ($cartItem) {
                            
                        } else {
                            // Product not in the cart, add it
                            $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, $quantity)");
                        }
                    }
                }

                unset($_SESSION['cart']);
            }




            // Redirect to a logged-in user page or any other page
            header("Location: index.php"); // Replace with your desired page
            exit();
        } else {
            $loginError = "Invalid password. Please try again.";
        }
    } else {
        $loginError = "Invalid email. Please try again.";
    }

}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <div class="wrapper">
            <form action="" method="POST" id="dreamit-forms">
                <h2>Login</h2>
                <div class="input-field">
                    <input type="email" name="email" required>
                    <label>Enter your email</label>
                </div>
                <div class="input-field">
                    <input type="password" name="password" required>
                    <label>Enter your password</label>
                </div>
                <div class="forget">
                 
                    <a href="#">Forgot password?</a>
                </div>

                <?php
                if (isset($loginError)) {
                    echo '<div class="error-message">' . $loginError . '</div>';
                }
                ?>

                <button type="submit" name="login-now">Log In</button>
                <div class="register">
                    <p>Don't have an account? <a href="signup.php">Register</a></p>
                </div>
            </form>
        </div>
    </main>

    <?php include "includes/footer.php"; ?>

    <script src="js/script.js"></script>
    <script>
        document.getElementById('login-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            window.location.href = '/'; 
        });
    </script>
</body>

</html>
