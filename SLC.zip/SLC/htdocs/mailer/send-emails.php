
<?php

    require_once '../database.php';
    require_once '../auth-admin.php';
    
    
    
    if (!$isAdminLoggedIn) {
    	header("location: ../index.php");
    }

?>

<!DOCTYPE html>
<html>
<head>
  <title> E-Mail System - Green Delivery</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="assets/css/style.css">
  
  
</head>
<body>

<div class="container p-4">





<?php




use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';



if(isset($_POST["sndBtn"])){

    try {
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        
        
        $mail->isSMTP();  
        $mail->Host       = $_POST["smtp_server"];                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = $_POST["smtp_email"];                     //SMTP username
        $mail->Password   = $_POST["smtp_pass"];                               //SMTP password
        
        if(isset($_POST["smtp_ssl"])){
            $mail->SMTPSecure = "ssl"; 
        }
        else{
            $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
        }
        
        if(isset($_POST["smtp_port"])){
            if($_POST["smtp_port"] != ""){
                $mail->Port = $_POST["smtp_port"];
            }
        }
        
       
        
    
        //Recipients
        $mail->setFrom($_POST["email"], $_POST["name"]);
        
        
        
        
        //Set Receiving Emails
        $toEmails = explode("\n",$_POST["sendTo"]);
        
        foreach($toEmails as $e) {
            $e = trim($e);
            $mail->addAddress($e);
            
        }
        
        
        
        //Set CC Emails
        if(trim($_POST["sendCC"]) != ""){
            $CCEmails = explode("\n",$_POST["sendCC"]);
            foreach($CCEmails as $cc) {
                $cc = trim($cc);
                $mail->addCC($cc);
                
            }
        }
        
        //Set BCC Emails
        if(trim($_POST["sendBCC"]) != ""){
            $BCCEmails = explode("\n",$_POST["sendBCC"]);
            
            foreach($BCCEmails as $bcc) {
                $bcc = trim($bcc);
                $mail->addBCC($bcc);
                
            }
        
        }
        
        
        //Add reply to emial if any
        if(isset($_POST["replyTo"])){
            if($_POST["replyTo"] != ""){
                $mail->addReplyTo($_POST["replyTo"], 'Information');
            }
        }
        
        
        
        
        if(!isset($_FILES['file1']) || $_FILES['file1']['error'] == UPLOAD_ERR_NO_FILE) {
            
        } else {
            $path = 'upload/' . $_FILES["file1"]["name"];
            move_uploaded_file($_FILES["file1"]["tmp_name"], $path);
            $mail->addAttachment($path);   
        }
        
        if(!isset($_FILES['file1']) || $_FILES['file1']['error'] == UPLOAD_ERR_NO_FILE) {
            
        } else {
            $path1 = 'upload/' . $_FILES["file2"]["name"];
            move_uploaded_file($_FILES["file2"]["tmp_name"], $path1);
            $mail->addAttachment($path1);   
        }
        
        
    
    
       
        
        $mail->Subject = $_POST["subject"];
        

        $mail->Body    = nl2br($_POST["msg"], false);
        
        
        
        
        if($_POST["type"] == 'html'){
            $mail->isHTML(true); 
        }else{
            $mail->isHTML(false); 
        }
           
        $mail->AltBody = nl2br($_POST["msg"], false);

        
        
    
        $mail->send();
        
        unlink($path);
        unlink($path1);
        
        
        echo '<div class="alert alert-success" role="alert">Success! Message Has Been sent.</div>';
    } catch (Exception $e) {
        
        echo '<div class="alert alert-danger" role="alert">Error! Message could not be sent. <br>Here are few details: <br>'.$mail->ErrorInfo . '</div>';
    }
    



}










?>

<br>

<a href="index.php" class="btn btn-primary">Back to Mailer</a>

</div>
<!-- Container End -->



</body>
</html>