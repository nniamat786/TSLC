<?php
    require_once '../database.php';
    require_once '../auth-admin.php';
    

    
    if (!$isAdminLoggedIn) {
    	header("location: ../index.php");
    }


?>



<!DOCTYPE html>
<html>
<head>
  <title> E-Mail System - Green Delivery</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="assets/css/style.css">
  
  
</head>
<body>

<div class="container">
    <div class="heading-area">
        <h3> <mark> E-Mail System - Green Delivery </mark> </h3>
    </div>
    
    <form action="send-emails.php" method="POST" enctype="multipart/form-data">
    
    <div class="section-head">
        <h5>SMTP Setup</h5>
    </div>
    
    <div class="row smtp">
        <div class="col-md-2 text-right">
            <span>SMTP Login</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="smtp_email" class="w-75" value="office@green-delivery.pw">
        </div>
        <div class="col-md-2 text-right">
            <span>SMTP Password</span>
        </div>
        <div class="col-md-4">
            <input type="password" name="smtp_pass" class="w-75">
        </div>
    </div>
    
    <div class="row smtp">
        <div class="col-md-2 text-right">
            <span>Port:</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="smtp_port" class="w-25"> <span>(Optional)</span>
        </div>
        <div class="col-md-2 text-right">
            <span>SMTP Server</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="smtp_server" class="w-75" value="server124.web-hosting.com">
        </div>
    </div>
    
    
    <div class="row smtp">
        <div class="col-md-2 text-right">
            <span>SSL Server</span>
        </div>
        <div class="col-md-4">
            <input type="checkbox" name="smtp_ssl" class="check">
        </div>
        <div class="col-md-2 text-right">
            <span>Reconnect After</span>
        </div>
        <div class="col-md-4">
            <input type="number" name="smtp_reconnect" class="w-25">
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12 text-right">
            <span>*If you dont have SMTP login. Leave above queries blank.</span>
        </div>
    </div>
    
    <div class="section-head">
        <h5>Message Setup</h5>
    </div>
    
    <div class="row msg">
        <div class="col-md-2 text-right">
            <span>Attach File 1</span>
        </div>
        <div class="col-md-4">
            <input type="file" name="file1" class="w-75 file">
        </div>
        <div class="col-md-2 text-right">
            <span>Attach File 2</span>
        </div>
        <div class="col-md-4">
            <input type="file" name="file2" class="w-75 file">
        </div>
    </div>
    
    <div class="row msg">
        <div class="col-md-2 text-right">
            <span>Your Email*</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="email" class="w-75" value="office@green-delivery.pw" required>
        </div>
        <div class="col-md-2 text-right">
            <span>Your Name*</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="name" class="w-75" required>
        </div>
    </div>
    
    <div class="row msg">
        <div class="col-md-2 text-right">
            <span>Reply To</span>
        </div>
        <div class="col-md-4">
            <input type="text" name="replyTo" class="w-75">
        </div>
        <div class="col-md-2 text-right">
            <span>Email Priority</span>
        </div>
        <div class="col-md-4">
            <select name="priority" class="select w-50">
                <option value="1">--Choose Priority</option>
            </select>
        </div>
    </div>
    
    <div class="row msg">
        <div class="col-md-2 text-right">
            <span>Subject*</span>
        </div>
        <div class="col-md-10">
            <input type="text" name="subject" class="w-75" required>
        </div>
    </div>
    
    
    <div class="row msg">
        <div class="col-md-4">
            <span>Send To(One Email address Per Line)*</span>
            <textarea class="w-100" name="sendTo" rows="7" required></textarea>
        </div>
        <div class="col-md-4">
            <span>Send CC(One Email address Per Line)</span>
            <textarea class="w-100" name="sendCC" rows="7"></textarea>
        </div>
        <div class="col-md-4">
            <span>Send BCC(One Email address Per Line)</span>
            <textarea class="w-100" name="sendBCC" rows="7"></textarea>
        </div>
    </div>
    
    
    <div class="row msg">
        <div class="col-md-12">
            <span>Message*</span>
            <textarea class="w-100" name="msg" rows="10" required></textarea>
            <input type="radio" name="type" value="text" class="radio" checked> Plain Text
            <input type="radio" name="type" value="html" class="radio"> HTML
        </div>
    </div>
    
    
    <div class="row">
        <div class="col-md-12 text-right">
            <input type="submit" name="sndBtn" value="Send Message" class="send-btn">
        </div>
    </div>
    
    
    </form>
    
    
    
        
     
    
    
</div>
<!-- Container End -->



</body>
</html>
