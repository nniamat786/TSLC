<?php 
include "config.php";

$id = $_GET['id'];

$product = $conn->query("SELECT * FROM products where id = $id")->fetch_assoc();
$productCategory = $product['category'];

$category = $conn->query("SELECT * FROM categories where id = $productCategory")->fetch_assoc();
$categoryGender = $category['gender'];

$others = $conn->query("SELECT * FROM categories where gender = '$categoryGender' and id != $productCategory LIMIT 0,3;");


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club</title>
    <?php include "includes/links.php"; ?>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-header {
            background: #000;
            color: #fff;
            text-align: center;
            padding: 0.25rem 0;
            font-size: 0.9rem;
        }

       

        .currency {
            margin-left: 1rem;
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            text-align: center;
            flex-grow: 1;
        }

        .header-links {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-right: 1rem;
        }

        .header-links a {
            text-decoration: none;
            color: #000;
            font-weight: bold;
        }

        .header-content {
            background: #fff;
            color: #000;
            text-align: center;
            padding: 1rem 0;
        }

        .main-nav {
            text-align: center;
            padding: 0.5rem 0;
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
        }

        nav ul {
            list-style: none;
            display: inline-flex;
            gap: 2rem;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            position: relative;
        }

        nav ul li a {
            text-decoration: none;
            color: #000;
            font-weight: bold;
            font-size: 1.2rem;
            font-family: 'Arial', sans-serif;
        }

        nav ul li a:hover {
            color: #666; /* Light gray color */
            text-decoration: none;
        }

        nav ul li a::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: #000;
            transition: width .3s;
        }

        nav ul li a:hover::after {
            width: 100%;
            transition: width .3s;
        }

        .hidden {
            display: none;
        }

        #floating-search-bar {
            position: absolute;
            top: 60px;
            right: 20px;
            background: #fff;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .product-detail {
            padding: 2rem 0;
        }

        .product-detail .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .product-images {
            flex: 1;
            max-width: 50%;
        }

        .product-images .main-image {
            width: 100%;
            height: auto;
            cursor: pointer;
        }

        .thumbnail-images {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .thumbnail-images img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            cursor: pointer;
        }

        .product-info {
            flex: 1;
            max-width: 45%;
        }

        .product-info h1 {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .product-details {
            list-style: none;
            padding: 0;
            margin-bottom: 1rem;
            line-height: 25px;
        }

        .product-details li {
            margin-bottom: 0.5rem;
        }

        .product-sizes,
        .product-quantity {
            margin-bottom: 1rem;
        }

        .product-sizes label,
        .product-quantity label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .product-sizes select,
        .product-quantity input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn {
            display: block;
            width: 100%;
            text-align: center;
            padding: 1rem;
            background: #000000;
            color: #ffffff;
            border: none;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background: #333;
        }

        .find-size-section {
            background: #f4f4f4;
            padding: 1rem 0;
            text-align: center;
        }

        .find-size-section h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: normal;
        }

        .find-size-section p {
            margin: 0.5rem 0;
        }

        .find-size-btn {
            background: #000;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            cursor: pointer;
        }

        .find-size-btn:hover {
            background: #333;
        }

        .quick-picks {
            padding: 2rem 0;
        }

        .quick-picks h2 {
            font-size: 1.8rem;
            text-align: center;
        }

      
        .product {
            text-align: center;
            transition: transform 0.3s ease;
            flex: 1;
            max-width: 300px;
            cursor: pointer;
        }

        .product img {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        .product:hover {
            transform: scale(1.1);
        }

        

        .product-price{
            font-size: xx-large;
            font-weight: bold;
            color: black;
        }

    </style>



</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <section class="product-detail">
            <div class="container">
                <div class="product-images">
                    <img src="images/<?php echo $product['img'] ?>" alt="Classic Navy T-Shirt" class="main-image" onclick="window.location.href='model//'">
                    <div class="thumbnail-images">
                        <img src="images/tshirt (1).webp" alt="Classic Navy T-Shirt Thumbnail" onclick="window.location.href='model//'">
                    </div>
                </div>
                <div class="product-info">
                    <h1><?php echo $product['name'] ?></h1>
                    <p class="product-details">
                    <?php echo nl2br($product['description']) ?>
                    </p>

                    <p class="product-price">£<?php echo $product['price'] ?></p>

                    <div class="find-size-section">
                        <h2>The perfect size, every time</h2>
                        <p>Try SmartFit AI, our size recommendation tool today</p>
                        <button class="find-size-btn" onclick="window.location.href='model/'">Find my size</button>
                    </div>
                    <div class="product-sizes">
                        <label for="size">Size:</label>
                        <select id="size">
                            <option value="S">S</option>
                            <option value="M">M</option>
                            <option value="L">L</option>
                            <option value="XL">XL</option>
                        </select>
                    </div>
                    <div class="product-quantity">
                        <label for="quantity">Quantity:</label>
                        <input type="number" id="quantity" name="quantity" min="1" value="1">
                    </div>
                    <button class="btn" onclick="addToCart()">Add to Basket</button>
                </div>
            </div>
        </section>
        <section class="quick-picks">
            <h2>You May Also Like</h2>
            <div class="products">
                <?php 
                while ($row = $others->fetch_assoc()) {
                    ?>
                        <div class="product">
                            <a href="category.php?id=<?php echo $row['id']; ?>">
                                <img src="images/<?php echo $row['img']; ?>" alt="Men T-Shirt">
                                <p><?php echo $row['name']; ?></p>
                            </a>
                        </div>
                    <?php
                }
                ?>
               
            </div>
        </section>
    </main>

    <script>
        
        // Add to Cart button click event
        function addToCart() {
            var productId = <?php echo $id; ?>; // Get product ID from PHP variable
            var quantity = document.getElementById("quantity").value;
            var data = {
                id: productId,
                quantity: quantity
            };

            $.ajax({
                type: 'POST',
                url: 'addToCart.php', 
                data: data,
                success: function(response) {
                    alert(response); // Display response from the server

                    


                },
                error: function(error) {
                    console.error('Error adding to cart:', error);
                }
            });
        }

       
    </script>


    <?php include "includes/footer.php"; ?>
    <script src="js/script.js"></script>
</body>

</html>
