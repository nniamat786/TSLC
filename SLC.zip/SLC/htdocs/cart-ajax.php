<?php
include "config.php";

// Check if the form is submitted for updating the cart
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                updateCart();
                break;
            case 'remove':
                removeFromCart();
                break;
            default:
                http_response_code(400);
                echo "Invalid action";
        }
    }
    exit();
}

// Function to update the cart
function updateCart()
{
    global $conn;

    if (isset($_POST['id'], $_POST['quantity'])) {
        $productId = $_POST['id'];
        $quantity = $_POST['quantity'];

        // Check if the user is logged in
        if (isset($_SESSION['user_id'])) {

            $userId = $_SESSION['user_id'];
            
            // Assumes there is a 'cart' table in the database
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("iii", $quantity, $userId, $productId);
            $stmt->execute();
            $stmt->close();

            echo json_encode(['status' => 'success', 'message' => "Cart updated for registered user with quantity: $quantity"]);
        } else {
            // Guest user
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = array();
            }

            // Update the quantity for the product in the cart
            $_SESSION['cart'][$productId] = $quantity;

            echo json_encode(['status' => 'success', 'message' => "Cart updated for guest user with quantity: $quantity"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
    }
}

// Function to remove from the cart
function removeFromCart()
{
    global $conn;
    
    if (isset($_POST['id'])) {
        $productId = $_POST['id'];

        // Check if the user is logged in
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            
            // Assumes there is a 'cart' table in database
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $userId, $productId);
            $stmt->execute();
            $stmt->close();

            echo json_encode(['status' => 'success', 'message' => 'Product removed for registered user']);
        } else {
            // Guest user
            if (isset($_SESSION['cart'][$productId])) {
                // Remove the product from the cart
                unset($_SESSION['cart'][$productId]);

                echo json_encode(['status' => 'success', 'message' => 'Product removed from the cart']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Product not found in the cart']);
            }
        }
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
    }
}
?>