<?php
include "config.php";

// Fetch cart items based on user type (registered or guest)
if (isset($_SESSION['user_id'])) {
    // Registered user
    $user_id = $_SESSION['user_id'];
    $cartItems = $conn->query("SELECT p.*, c.quantity FROM cart c INNER JOIN products p ON c.product_id = p.id WHERE c.user_id = $user_id")->fetch_all(MYSQLI_ASSOC);
} else {
    // Guest user
    $cartItems = array();
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
            if ($product) {
                $product['quantity'] = (int)$quantity;
                $cartItems[] = $product;
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - The Secret Label Club</title>
    <link rel="stylesheet" href="css/cart.css">
    <?php include "includes/links.php"; ?>
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <div class="container" style=" display: block; "> 
        <main>
            <div class="breadcrumb">
                <a href="/">Home</a> / <span>Basket</span>
            </div>
            <h1>Basket</h1>
            <div class="cart">
                <table>
                    <thead>
                        <tr>
                            <th>PRODUCT</th>
                            <th>IMAGE</th>
                            <th>PRODUCT</th>
                            <th>PRICE (£)</th>
                            <th>QUANTITY</th>
                            <th>TOTAL (£)</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if (empty($cartItems)) { ?>
                            <tr>
                                <td colspan="6" class="empty-cart-message" style=" padding: 100px 5px; ">Your cart is empty.
                                </td>
                            </tr>
                        <?php } ?>


                        <?php foreach ($cartItems as $item): ?>
                            <tr>
                                <td class="product-remove"><a onclick="removeFromCart(<?php echo $item['id']; ?>)">×</a></td>
                                <td class="product-thumbnail"><img src="images/<?php echo $item['img']; ?>"
                                        alt="Lucite Incense Holder Set"></td>
                                <td class="product-name">
                                    <h3><?php echo $item['name']; ?></h3>
                                </td>
                                <td class="product-price" id="price-<?php echo $item['id']; ?>"><?php echo $item['price']; ?></td>
                                <td class="product-quantity">
                                    <div class="quantity">
                                        <button onclick="updateCart(<?php echo $item['id']; ?>, -1)" type="button"
                                            class="quantity-minus">−</button>
                                        <input type="number" value="<?php echo $item['quantity']; ?>" id="quantity-<?php echo $item['id']; ?>" min="1">
                                        <button onclick="updateCart(<?php echo $item['id']; ?>, 1)" type="button"
                                            class="quantity-plus">+</button>
                                    </div>
                                </td>
                                <td class="product-total" id="total-<?php echo $item['id']; ?>"><?php echo $item['price'] * $item['quantity']; ?></td>
                            </tr>
                        <?php endforeach; ?>





                    </tbody>
                </table>
              
                <div class="cart-totals">
                    <h3>Basket Totals</h3>

                    <table>
                        <tbody>
                            <tr>
                                <th>Subtotal</th>
                                <?php
                                $subtotal = 0;
                                foreach ($cartItems as $item) {
                                    $subtotal += $item['price'] * $item['quantity'];
                                }
                                ?>
                                <td id="subtotal">£<?php echo $subtotal; ?></td>
                            </tr>
                            <tr>
                                <th>Taxes and shipping not included</th>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                    <form action="payment-success.php" method="POST" style=" margin: 0px; margin-top: 20px;">
                        <div>
                            <label>Email Address</label>
                            <input type="text" name="email" value=" <?php if(isset($_SESSION['user_email'])){ echo $_SESSION['user_email'];} ?>" required>
                        </div>
                        <button style=" display: inline-block; " href="payment-success.php" type="<?php if($subtotal > 0){ echo "submit";} else{ echo 'button';} ?>" class="checkout-btn">Checkout Now</button>
                    </form>
                </div>
            </div>
        </main>
    </div>


    <script>
        function updateCart(productId, quantityChange) {
            var currentQuantity = parseInt($('#quantity-' + productId).val());
            var newQuantity = currentQuantity + quantityChange;

            // Ensure the quantity doesn't go below 1
            newQuantity = Math.max(1, newQuantity);

            console.log(newQuantity);

            $.ajax({
                url: 'cart-ajax.php',
                method: 'POST',
                data: {
                    action: 'update',
                    id: productId,
                    quantity: newQuantity
                },
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        // Update the quantity display and subtotal
                        $('#quantity-' + productId).val(newQuantity);
                        
                        // Update the product total
                        var price = parseFloat($('#price-' + productId).text().replace('$', ''));
                        var newTotal = price * newQuantity;
                        $('#total-' + productId).text('' + newTotal.toFixed(2));
                        
                        // Update the subtotal
                        updateSubtotal();

                    } else {
                        console.error('Error updating cart:', response.message);
                    }
                },
                error: function (error) {
                    console.error('Error updating cart:', error);
                }
            });
        }

        function removeFromCart(productId) {
            $.ajax({
                url: 'cart-ajax.php',
                method: 'POST',
                data: {
                    action: 'remove',
                    id: productId
                },
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        // Remove the corresponding row from the table
                        $('#quantity-' + productId).closest('tr').remove();
                        
                        // Update the subtotal
                        updateSubtotal();

                    } else {
                        console.error('Error removing from cart:', response.message);
                    }
                },
                error: function (error) {
                    console.error('Error removing from cart:', error);
                }
            });
        }

        function updateSubtotal() {
            var subtotal = 0;
            $('.product-total').each(function () {
                subtotal += parseFloat($(this).text().replace('', ''));
            });
            $('#subtotal').text('£' + subtotal.toFixed(2));
        }


    </script>


    <?php include "includes/footer.php"; ?>
    <script src="js/script.js"></script>
</body>

</html>