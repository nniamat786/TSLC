<?php
include 'config.php';


if(isset($_POST['register-now'])){

    $fname = $_POST['fname'];
    $lName = $_POST['lName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    // Check if passwords match
    if ($password != $password2) {
        $loginError =  "Passwords do not match";
    }

    $password = password_hash($password, PASSWORD_BCRYPT);

    // Check if the email already exists
    $existingUser = $conn->query("SELECT * FROM users WHERE email = '$email'")->fetch_assoc();

    if ($existingUser) {
        $loginError = "Email already exists. Please use a different email.";
    } else {
        // Insert the new user into the database
        $result = $conn->query("INSERT INTO users (fName, lName, email, password) VALUES ('$fname', '$lName', '$email', '$password')");

        if ($result) {
            header("location: login.php");
            die;
        } else {
            $loginError = "Registration failed. Please try again.";
        }
    }
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <main>
        <div class="wrapper">
            <form action="" method="POST" id="dreamit-forms">
                <h2 style=" margin-bottom: 40px; text-align: center; ">Register</h2>
                <div class="input-field">
                    <input type="text" name="fname" required>
                    <label for="name">Enter first name</label>
                </div>
                <div class="input-field">
                    <input type="text" name="lName" required>
                    <label for="address">Enter last name</label>
                </div>
                <div class="input-field">
                    <input type="email" name="email" required>
                    <label for="id-card-number">Enter your Email Address</label>
                </div>
                <div class="input-field">
                    <input type="text" name="phone" required>
                    <label for="phone-number">Enter your phone number</label>
                </div>
               
                <div class="input-field">
                    <input type="password" name="password" required>
                    <label for="password">Enter your password</label>
                </div>

                <div class="input-field">
                    <input type="password" name="password2" required>
                    <label for="password">Enter confirm password</label>
                </div>


                <div class="my-3">
                <?php
                if (isset($loginError)) {
                    echo '<div class="error-message">' . $loginError . '</div>';
                }
                ?>
                </div>


                <button type="submit" name="register-now">Register</button>
                <div class="login">
                    <p>Already have an account? <a href="login.php">Login</a></p>
                </div>
            </form>
        </div>
    </main>

    <?php include "includes/footer.php"; ?>

    <script src="js/script.js"></script>
    <script>
        document.getElementById('register-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            // Add form validation checks here
            alert('Registration successful!');
            window.location.href = '/'; // Redirect to /
        });
    </script>
</body>

</html>

