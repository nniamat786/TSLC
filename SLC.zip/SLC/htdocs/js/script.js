document.getElementById('search-icon').addEventListener('click', function () {
    var searchBar = document.getElementById('floating-search-bar');
    searchBar.classList.toggle('hidden');
});

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('mouseover', function () {
        var dropdown = this.querySelector('.dropdown');
        dropdown.classList.add('show');
        dropdown.classList.remove('hidden');
    });

    item.addEventListener('mouseout', function () {
        var dropdown = this.querySelector('.dropdown');
        dropdown.classList.add('hidden');
        dropdown.classList.remove('show');
    });
});

document.querySelectorAll('.thumbnail-images img').forEach(img => {
    img.addEventListener('click', function () {
        document.querySelector('.main-image').src = this.src;
    });
});
document.getElementById('search-icon').addEventListener('click', function () {
    var searchBar = document.getElementById('floating-search-bar');
    searchBar.classList.toggle('hidden');
});

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('mouseover', function () {
        var dropdown = this.querySelector('.dropdown');
        dropdown.classList.add('show');
        dropdown.classList.remove('hidden');
    });

    item.addEventListener('mouseout', function () {
        var dropdown = this.querySelector('.dropdown');
        dropdown.classList.add('hidden');
        dropdown.classList.remove('show');
    });
});

document.getElementById('order-form').addEventListener('submit', function (event) {
    event.preventDefault();

    var name = document.getElementById('name').value;
    var productName = document.getElementById('product-name').value;
    var productSize = document.getElementById('product-size').value;
    var productQuantity = document.getElementById('product-quantity').value;
    var shippingAddress = document.getElementById('shipping-address').value;
    var paymentMethod = document.querySelector('input[name="payment-method"]:checked');

    if (!name || !productName || !productSize || !productQuantity || !shippingAddress || !paymentMethod) {
        alert('Please fill out all fields before submitting.');
    } else {
        alert('Order placed successfully!');
       
        document.getElementById('order-form').reset();
    }
});



