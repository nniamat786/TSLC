<?php 
include "config.php";



$categories = $conn->query("SELECT * FROM categories where gender = 'Men'");


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <section class="category-section">


            <?php  
            while($row = $categories->fetch_assoc()){ 
                $productCategory = $row['id'];
                $products = $conn->query("SELECT * FROM products where category = $productCategory");

            ?>

            <section class="quick-picks men">
                <h2><?php echo $row['name'] ?></h2>
                <div class="products">
                    <?php 
                    while ($row = $products->fetch_assoc()) {
                        ?>
                            <div class="product">
                                <a href="product.php?id=<?php echo $row['id']; ?>">
                                    <img src="images/<?php echo $row['img']; ?>" alt="Men T-Shirt">
                                    <p><?php echo $row['name']; ?></p>
                                </a>
                            </div>
                        <?php
                    }
                    ?>
                </div>
            </section>

            <?php 
            }
            ?>

            

         

           
        </section>
    </main>

    <?php include "includes/footer.php"; ?>

    <script src="js/script.js"></script>
</body>

</html>
