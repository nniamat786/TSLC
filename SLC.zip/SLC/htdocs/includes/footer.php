<footer>
        <div class="container">
            <div class="payment-icons">
                <img src="/images/payments.png" alt="Payment Methods">
               
            </div>
            <p>&copy; The Secret Label Club 2024</p>
            <nav>
                <a href="terms-and-conditions.php">Terms & Conditions</a>
                <a href="terms-and-conditions.php">Privacy Policy</a>
            </nav>
        </div>
    </footer>