<header>
    <div class="top-header">
        <div class="free-delivery">FREE DELIVERY ON ALL ORDERS OVER £60</div>
    </div>
    <div class="middle-header">
        <div class="container">
            <div class="currency">United Kingdom GBP £</div>
            <div class="logo"><a href="/" style="text-decoration: none; color: inherit;">The Secret Label Club</a></div>
            <div class="header-links">

                <?php if (isset($_SESSION['user_id'])) { ?>

                    <a href="#" id="account-icon"><i class="fas fa-user"></i>
                        <?php echo $_SESSION['fName'] . " " . $_SESSION['lName'] ?> </a>
                    <div id="account-dropdown" class="dropdown-content">
                        <a href="/logout.php">Logout</a>
                    </div>


                <?php } else {
                    ?>
                    <a href="/login.php"><i class="fas fa-user"></i> Login </a>
                    <?php
                } ?>


               
                <a href="/cart.php"><i class="fas fa-shopping-cart"></i> Basket</a>
            </div>
        </div>
    </div>
    <div class="header-content">
        <nav class="main-nav">
            <ul>
                <li class="nav-item">
                    <a href="/men_prod.php" id="men-link">MEN</a>
                </li>
                <li class="nav-item">
                    <a href="/wmen_prod.php" id="women-link">WOMEN</a>
                </li>
            </ul>
        </nav>
    </div>
</header>



<style>
    .account-menu {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
        top: 30px;
        border: 1px solid #e4dfdc;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }

    .account-menu:hover .dropdown-content {
        display: block;
    }
</style>

<script>

    if (document.getElementById('account-icon') != null) {
        document.getElementById('account-icon').addEventListener('click', function (event) {
            event.preventDefault();
            var dropdown = document.getElementById('account-dropdown');
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
            } else {
                dropdown.style.display = 'block';
            }
        });
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function (event) {
        if (!event.target.matches('#account-icon') && !event.target.matches('#account-icon *')) {
            var dropdowns = document.getElementsByClassName('dropdown-content');
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.style.display === 'block') {
                    openDropdown.style.display = 'none';
                }
            }
        }
    }
</script>