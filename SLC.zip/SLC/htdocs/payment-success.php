<?php
include "config.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'mailer/PHPMailer/src/Exception.php';
require 'mailer/PHPMailer/src/PHPMailer.php';
require 'mailer/PHPMailer/src/SMTP.php';





$emailAddress = $_POST['email'];



$userId = 'null';
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $cartItems = $conn->query("SELECT p.*, c.quantity FROM cart c INNER JOIN products p ON c.product_id = p.id WHERE c.user_id = $userId")->fetch_all(MYSQLI_ASSOC);
}
else {
	// Guest user
	$cartItems = array();
	if (isset($_SESSION['cart'])) {
		foreach ($_SESSION['cart'] as $product_id => $quantity) {
			$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
			if ($product) {
				$product['quantity'] = $quantity;
				$cartItems[] = $product;
			}
		}
	}
}



$sql = "INSERT INTO orders (userId, email) VALUES ('$userId', '$emailAddress')";


if ($conn->query($sql) === TRUE) {
    $lastId = $conn->insert_id;

	foreach ($cartItems as $item){
        $productid = $item['id'];
        $quantity = $item['quantity'];

        $conn->query("INSERT INTO `order_items` (`orderId`, `productId`, `quantity`) VALUES ('$lastId', '$productid', '$quantity')");
    }
    if (isset($_SESSION['user_id'])) {
        $conn->query("DELETE from cart WHERE user_id = $userId");
    }
    else{
        unset($_SESSION['cart']);
    }
} 


$orderItems = $conn->query("SELECT p.*, o.quantity FROM order_items o INNER JOIN products p ON o.productId = p.id WHERE o.orderId = $lastId")->fetch_all(MYSQLI_ASSOC);

$htmlContent = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
        }

        h1, h2, h3 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        p {
            margin-bottom: 10px;
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Order Receipt</h1>
    <p>Thank you for your order! Below is the receipt for your recent purchase:</p>
    <h2>Order Details</h2>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>';


$totalAmountPaid = 0;     
foreach ($cartItems as $item) {
    $productName = $item['name'];
    $quantity = $item['quantity'];
    $price = $item['price'] * $quantity;

    $totalAmountPaid = $totalAmountPaid + $price;

    $htmlContent .= "
            <tr>
                <td>{$productName}</td>
                <td>{$quantity}</td>
                <td>£ {$price}</td>
            </tr>";
}


$htmlContent .= '
        </tbody>
    </table>

    <h3>Total Amount Paid: £ ' . number_format($totalAmountPaid, 2) . '</h3>

    <p>Thank you for shopping with The Secret Label Club. If you have any questions or concerns, please contact our customer support.</p>

    <div class="footer">
        <p>The Secret Label Club | admin@thesecretlabelclub.com</p>
    </div>
</body>
</html>';




$mail = new PHPMailer(true);
$mail->SMTPDebug = 0;
$mail->isSMTP(); 
$mail->Host = 'mail.privateemail.com';
$mail->SMTPAuth   = true;
$mail->Username   = 'notifications@thesecretlabelclub.com';
$mail->Password   = 'sdfsdf345dfg45$';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;    

$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';
$mail->setFrom("notifications@thesecretlabelclub.com", "The Secret Label Club Notifications");

$mail->addAddress($emailAddress);
$mail->Subject = "Order Placed successfully | The Secret Label Club";

$mail->Body    = $htmlContent;
$mail->isHTML(true); 
$mail->send();






//Send email to Admin
$htmlContent = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
        }

        h1, h2, h3 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        p {
            margin-bottom: 10px;
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Order Confirmed</h1>
    <p>User placed an order! Below is the receipt for this purchase:</p>
    <h2>Order Details</h2>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>';


$totalAmountPaid = 0;     
foreach ($cartItems as $item) {
    $productName = $item['name'];
    $quantity = $item['quantity'];
    $price = $item['price'] * $quantity;

    $totalAmountPaid = $totalAmountPaid + $price;

    $htmlContent .= "
            <tr>
                <td>{$productName}</td>
                <td>{$quantity}</td>
                <td>£ {$price}</td>
            </tr>";
}


$htmlContent .= '
        </tbody>
    </table>

    <h3>Total Amount Paid: £ ' . number_format($totalAmountPaid, 2) . '</h3>


    <div class="footer">
        <p>Admin Notifications | The Secret Label Club</p>
    </div>
</body>
</html>';




$mail = new PHPMailer(true);
$mail->SMTPDebug = 0; //  0 = off, 1 = commands, 2 = commands and data
$mail->isSMTP(); 
$mail->Host = 'mail.privateemail.com';
$mail->SMTPAuth   = true;
$mail->Username   = 'notifications@thesecretlabelclub.com';
$mail->Password   = 'sdfsdf345dfg45$';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;    

$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';
$mail->setFrom("notifications@thesecretlabelclub.com", "The Secret Label Club Notifications");


$mail->addAddress('Niamat.nasrati@hotmail.com');

$mail->Subject = "Order Confirmed | Admin | The Secret Label Club";

$mail->Body    = $htmlContent;
$mail->isHTML(true); 
$mail->send();




?>
<!DOCTYPE html>
<html lang="en-US"
	class=" sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Order Placed | The Secret Label Club</title>
	<?php include 'includes/links.php';?>


</head>
<body>
	<?php include 'includes/header.php';?>

	<br><br><br><br><br><br><br><br>

    <div class="subscription-success">
        <div class="container" style=" width: 340px; text-align: center; display: block; ">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <img src="/images/Purchase_Success.png" alt="Success Image" width="300px">
                    <h2 style="margin-bottom: 8px;">Order placed Successfully</h2>
                    <p>You will get confirmation email shortly</p>
                    <a href="/" class="btn btn-primary">Back to Home</a>
                </div>
            </div>
        </div>
    </div>

    <br><br><br><br><br><br><br>



	<?php include 'includes/footer.php';?>
</body>
</html>