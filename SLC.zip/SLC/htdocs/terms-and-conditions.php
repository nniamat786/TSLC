<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Secret Label Club</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>
    <?php include "includes/header.php"; ?>

    <div id="floating-search-bar" class="hidden">
        <input type="text" placeholder="Search...">
    </div>

    <main>
        <div class="container" style=" display: block; margin-bottom: 70px; ">
            <h1>Terms and Conditions</h1>
            <section>
                <h2>Ordering</h2>
                <p>All orders are subject to acceptance and availability. If the goods ordered are not available, you will be notified by email and you will have the option either to wait until the item is available from stock or to cancel your order.</p>
                <p>We reserve the right to refuse an order. Non-acceptance of an order may, for example, result from one of the following:</p>
                <ul>
                    <li>The product ordered being unavailable from stock</li>
                    <li>Our inability to obtain authorization for your payment</li>
                    <li>The identification of a pricing or product description error</li>
                </ul>
            </section>

            <section>
                <h2>Material of Stock</h2>
                <p>We ensure that all materials used in our products are of high quality and sourced responsibly. However, we cannot guarantee that the colors of the products will be exactly as seen on your monitor. Variations may occur due to the nature of the material or the screen settings.</p>
                <p>We take care to describe the materials and provide accurate descriptions, but slight variations in texture, color, or material can occur. If you have specific concerns about a material, please contact us before placing your order.</p>
            </section>

            <section>
                <h2>Returns and Refunds</h2>
                <p>If you are not satisfied with your purchase, you may return the items within 30 days for a refund or exchange. The items must be in their original condition, unused, and with all tags attached.</p>
                <p>Please contact our customer service team to initiate a return and for further instructions.</p>
            </section>
        </div>
    </main>

    <?php include "includes/footer.php"; ?>

    <script src="js/script.js"></script>
</body>

</html>

