-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2024 at 01:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `secret_label_club`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`) VALUES
(8, 2, 1, 2),
(9, 2, 12, 1),
(10, 2, 25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` enum('Men','Women') NOT NULL,
  `img` varchar(255) NOT NULL,
  `ordr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `gender`, `img`, `ordr`) VALUES
(1, 'T-Shirts', 'Men', 'men-tshirt.png', 1),
(2, 'Polo Shirts', 'Men', 'men-polo.png', 2),
(3, 'Shirts', 'Men', 'men-shirt.png', 3),
(4, 'T-Shirts', 'Women', 'women-tshirt.png', 4),
(5, 'Dresses', 'Women', 'women-dress.png', 5),
(6, 'Knitwear', 'Women', 'women-knitwear.png', 6),
(7, 'Formalwear', 'Men', 'suits%20(1).webp', 7),
(8, 'Trousers', 'Men', 'trousers%20(2).webp', 8),
(9, 'Jackets & Coats\n', 'Men', 'jacket%20(1).webp', 9),
(10, 'Shoes', 'Women', 'wshoe%20(1).webp', 10),
(11, 'Trousers', 'Women', 'wtrouser%20(1).webp', 11),
(12, 'Knitwear', 'Men', 'knitwear%20(1).webp', 12),
(14, 'Sweat Shirts', 'Women', 'wsample%20(2).webp', 14);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `email`) VALUES
(7, 0, 'niamat.nasrati@gmail.com'),
(8, 0, 'niamat.nasrati@gmail.com'),
(9, 0, 'niamat.nasrati@gmail.com'),
(10, 0, ' niamat.nasrati@gmail.com'),
(11, 0, ' niamat.nasrati@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `orderId`, `productId`, `quantity`) VALUES
(1, 1, 2, 3),
(2, 1, 13, 5),
(3, 1, 20, 1),
(4, 1, 10, 1),
(5, 5, 1, 1),
(6, 6, 1, 33),
(7, 7, 1, 2),
(8, 10, 39, 5),
(9, 11, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `description` text NOT NULL,
  `category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `img`, `price`, `description`, `category`) VALUES
(1, 'Classic T‑shirt Black', 'tshirt%20(2).webp', 150, 'Black\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 1),
(2, 'Classic T-Shirt Blue', 'tshirt%20(1).webp', 145.99, 'Blue\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 1),
(3, 'Ribbed T-Shirt White', 'tshirt%20(3).webp', 159.99, 'White\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 1),
(5, 'Crew Neck Jumper', 'knitwear%20(1).jpg', 130, 'Black Crafted from organic cotton Micro-ribbed crew neck Short sleeves Total stitching Straight hem Made in USA', 12),
(6, 'Textured Knit', 'knitwear%20(1).webp', 99.99, 'Grey\nCrafted from organic cotton\nMicro-ribbed crew neck\nLong sleeves\nTotal stitching\nMade in USA', 12),
(7, 'Cashmere Crew Neck Jumper', 'knitwear%20(2).webp', 110, 'Brown\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA\nKey features include:\n\nPremium Cashmere: Made from 100% high-quality cashmere, ensuring a luxurious feel against the skin.\nClassic Crew Neck Design: Features a versatile crew neck that complements any outfit, whether layered or worn on its own.\nExceptional Softness: The cashmere fabric is incredibly soft and cozy, providing superior comfort.\nTailored Fit: Designed to flatter your silhouette with a modern, tailored fit that is both comfortable and stylish.\nVersatile Style: Available in a range of classic and contemporary colors, perfect for any wardrobe.\nIdeal for both casual and dressy occasions, this Cashmere Crew Neck Jumper pairs effortlessly with jeans, chinos, or skirts. Whether you\'re heading to the office, out for a casual day, or enjoying a cozy evening at home, this jumper ensures you stay warm and stylish.\n\nElevate your knitwear collection with this luxurious Cashmere Crew Neck Jumper, a true essential for any fashion-forward wardrobe.', 12),
(8, 'Red & White Stripped', 'wtshirt%20(1).webp', 65.55, 'Red & White Stripped\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nMade in USA', 4),
(9, 'Polo shirt Blue', '54f47a9ARAGTS3011_1.avif', 249.99, 'Blue\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 2),
(10, 'Striped polo shirt black & white ', '02795405043-a1.jpg', 150, 'Black & White\nCrafted from organic cotton\nMicro-ribbed crew neck\nLong sleeves\nTotal stitching\nStraight hem\nMade in USA', 2),
(11, 'Striped Polo Ruby', 'mens-striped-polo-ruby-mullaghmore-429444-1.jpg', 49, 'Ruby\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 2),
(12, 'Mid-Weight T-Shirt Blue\n', 'wtshirt%20(2).webp', 59.99, 'Blue\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nMade in USA\n', 4),
(13, 'Ribbed Shirt Pink', 'wtshirt%20(3).webp', 45, 'Pink\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nShort sleeves\r\nTotal stitching\r\nMade in USA', 4),
(14, 'Crew Neck Jumper', 'knitwear%20(1).jpg', 130, 'Gray\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA\n', 6),
(15, 'Textured Knit', 'knitwear%20(1).webp', 99.99, 'Brown\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 6),
(16, 'Cashmere Crew Neck Jumper', 'knitwear%20(2).webp', 110, 'Black\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA\nKey features include:\n\nPremium Cashmere: Made from 100% high-quality cashmere, ensuring a luxurious feel against the skin.\nClassic Crew Neck Design: Features a versatile crew neck that complements any outfit, whether layered or worn on its own.\nExceptional Softness: The cashmere fabric is incredibly soft and cozy, providing superior comfort.\nTailored Fit: Designed to flatter your silhouette with a modern, tailored fit that is both comfortable and stylish.\nVersatile Style: Available in a range of classic and contemporary colors, perfect for any wardrobe.\nIdeal for both casual and dressy occasions, this Cashmere Crew Neck Jumper pairs effortlessly with jeans, chinos, or skirts. Whether you\'re heading to the office, out for a casual day, or enjoying a cozy evening at home, this jumper ensures you stay warm and stylish.\n\nElevate your knitwear collection with this luxurious Cashmere Crew Neck Jumper, a true essential for any fashion-forward wardrobe.', 6),
(17, 'Cotton Lined', 'wshoe%20(1).webp', 150, 'Black\nCrafted from organic cotton\nMicro-ribbed \nSmooth Feels\nTotal stitching\nMade in USA', 10),
(18, 'Smooth Finish\r\n', 'wshoe%20(2).webp', 225, 'Coloured\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nSmooth Feels\r\nTotal stitching\r\nMade in USA', 10),
(19, 'Flip flops ', 'wshoe%20(3).webp', 125, 'Black\nCrafted from organic cotton\nMicro-ribbed \nTotal stitching\nStraight hem\nMade in USA\n', 10),
(20, 'Spotted dress', 'wsample%20(3).webp', 279, 'Coloured\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nShort sleeves\r\nTotal stitching\r\nMade in USA', 5),
(21, 'Classic cotton\n', 'wsample%20(1).webp', 310, 'Black\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nShort sleeves\r\nTotal stitching\r\nStraight hem\r\nMade in USA', 5),
(22, 'Oxford Shirt\n', 'u92898s.webp', 150, 'White\nCrafted from organic cotton\nMicro-ribbed crew neck\nLong sleeves\nTotal stitching\nStraight hem\nMade in USA', 3),
(23, 'Notch lapel suit ocean blue', 'suits%20(1).webp', 550, 'The suit consists of a single-breasted blazer and matching pants. The blazer has two buttons, two front pockets, and a breast pocket, along with notched lapels. The sleeves are adorned with button details at the cuffs. The matching pants have an elastic waistband, offering a comfortable fit. This suit strikes a balance between formal and casual styles, suitable for various occasions.', 7),
(24, 'Notch lapel suit checked grey', 'suits%20(2).webp', 350, 'The suit includes a single-breasted blazer and matching pants. The blazer has two buttons, two front pockets, and a breast pocket, along with notched lapels. The sleeves feature button details at the cuffs. \nThe matching pants have a traditional waistband with belt loops and a button closure, providing a classic and polished look. This suit is ideal for formal occasions, offering a timeless and elegant style.', 7),
(25, 'Notch lapel suit navy', 'suits%20(3).webp', 325, 'The suit includes a single-breasted blazer and matching pants. The blazer has two buttons, two front pockets, and a breast pocket, along with notched lapels. The sleeves feature button details at the cuffs. \nThe matching pants have a traditional waistband with belt loops and a button closure, providing a classic and polished look. This suit is ideal for formal occasions, offering a timeless and elegant style.', 7),
(26, 'Classic jeans', 'trousers%20(2).webp', 175, 'The jeans are equipped with two side pockets and two back welt pockets, providing ample space for your essentials. Perfect for both casual and all other occasions, these chinos offer a timeless style that pairs effortlessly with a variety of tops and footwear. Upgrade your collection with these essential classic jeans and enjoy their comfort and versatility year-round.', 8),
(27, 'Pleated Linen Trouser', 'trousers%20(1).webp', 150, 'The chinos are equipped with two side pockets and two back welt pockets, providing ample space for your essentials. Perfect for both casual and semi-formal occasions, these chinos offer a timeless style that pairs effortlessly with a variety of tops and footwear. Upgrade your collection with these essential beige chinos and enjoy their comfort and versatility year-round.\nThe chinos are equipped with two side pockets and two back welt pockets, providing ample space for your essentials. Perfect for both casual and semi-formal occasions, these chinos offer a timeless style that pairs effortlessly with a variety of tops and footwear. Upgrade your collection with these essential beige chinos and enjoy their comfort and versatility year-round.', 8),
(28, 'Slim Fit Chino', 'trousers%20(3).webp', 150, 'These trousers are crafted from high-quality cotton fabric, ensuring both comfort and durability. The classic design features a straight-leg fit, a button closure with a zip fly, and belt loops for added functionality. \nThe chinos are equipped with two side pockets and two back welt pockets, providing ample space for your essentials. Perfect for both casual and semi-formal occasions, these chinos offer a timeless style that pairs effortlessly with a variety of tops and footwear. Upgrade your collection with these essential beige chinos and enjoy their comfort and versatility year-round.\nThe chinos are equipped with two side pockets and two back welt pockets, providing ample space for your essentials. Perfect for both casual and semi-formal occasions, these chinos offer a timeless style that pairs effortlessly with a variety of tops and footwear. Upgrade your collection with these essential beige chinos and enjoy their comfort and versatility year-round.', 8),
(29, 'Textured Shirt', '555186s.webp', 45.99, 'White\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA\nSignature Textured \nButton-through fastening\nLong sleeves\nEasy to iron\nTextured fabric\nMachine washable.\n65% Recycled polyester, 35% Cotton.', 3),
(30, 'Smooth Single Cuff Shirt ', 'u68502s7.webp', 50, 'White\nCrafted from organic cotton\nMicro-ribbed crew neck\nLong sleeves\nTotal stitching\nStraight hem\nMade in USA', 3),
(31, 'Cotton Linen Jacket', 'jacket%20(1).webp', 225, 'Crafted from a premium blend of cotton and linen, this jacket offers a breathable and lightweight feel, perfect for any season. The fabric\'s natural texture provides a sophisticated yet relaxed look, making it a versatile addition to your wardrobe.\n\nThe jacket features a classic multi button closure, and a tailored fit that enhances your silhouette. It includes two front pockets, and interior pockets, providing both functionality and style. The sleeves are adorned with buttoned cuffs, adding a refined touch to the overall design.', 9),
(32, 'Suede Twin Pocket Jacket', 'jacket%20(2).webp', 150, 'Crafted from a premium blend of cotton and linen, this jacket offers a breathable and lightweight feel, perfect for any season. The fabric\'s natural texture provides a sophisticated yet relaxed look, making it a versatile addition to your wardrobe.\n\nThe rich green color adds a touch of sophistication, making it perfect for both casual and semi-formal occasions. The jacket features a modern design with two spacious front pockets, providing ample storage for your essentials. The soft suede material offers a comfortable fit while adding a touch of elegance to your look.\n\nThe jacket features a classic multi button closure, and a tailored fit that enhances your silhouette. It includes two front pockets, and interior pockets, providing both functionality and style. The sleeves are adorned with buttoned cuffs, adding a refined touch to the overall design.Twin Front Pockets: Two large front pockets for practical storage and added style.\nVersatile Green Color: A rich green hue that complements a variety of outfits.\nComfortable Fit: Designed for comfort without compromising on style.\nPerfect for layering over a t-shirt or sweater, this Suede Twin Pocket Jacket in Green is a versatile piece that transitions seamlessly from day to night. Elevate your outerwear game with this timeless jacket, combining practicality with sophisticated style.', 9),
(33, 'Insulated Wool Gilet', 'jacket%20(3).webp', 175, 'The gilet features a classic zip closure, and a tailored fit that enhances your silhouette. It includes two front pockets, and interior pockets, providing both functionality and style. The sleeves are adorned with buttoned cuffs, adding a refined touch to the overall design.', 9),
(34, 'Pleated Linen Trouser', 'wtrouser%20(1).webp', 160, 'Coloured\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nSmooth Feels\r\nTotal stitching\r\nMade in USA', 11),
(35, 'Regular Fit Jeans', 'wtrouser%20(2).webp', 85, 'Coloured\r\nCrafted from organic cotton\r\nMicro-ribbed crew neck\r\nSmooth Feels\r\nTotal stitching\r\nMade in USA\r\n', 11),
(36, 'Slim Fit Chino', 'wtrouser%20(3).webp', 64.99, 'Black\nCrafted from organic cotton\nMicro-ribbed crew neck\nSmooth Feels\nTotal stitching\nMade in USA\n', 11),
(37, 'Sweat Shirt', 'wsample%20(2).webp', 60, 'Crafted from organic cotton\r\nMicro-ribbed crew neck\r\nShort sleeves\r\nTotal stitching\r\nStraight hem\r\nMade in USA', 14),
(38, 'Spot print dress black', '51_20000980001_1.jpg', 149, 'Navy & white spots\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 5),
(39, 'Self Wellness Club Sweatshirt\r\n', 'u12539s.webp', 30, 'Grey\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 14),
(40, 'Charcoal Grey Collared Sweatshirt', '948752s.webp', 29, 'Green\nCrafted from organic cotton\nMicro-ribbed crew neck\nShort sleeves\nTotal stitching\nStraight hem\nMade in USA', 14);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fName` varchar(255) NOT NULL,
  `lName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fName`, `lName`, `email`, `password`) VALUES
(2, 'Niamat', 'Nasrati', 'niamat.nasrati@gmail.com', '$2y$10$nWJ9ZAt4P4Wn8kE9IBMedeobBWgFD7Z6.kO4O3SWrvs1nYN9SxFPC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
